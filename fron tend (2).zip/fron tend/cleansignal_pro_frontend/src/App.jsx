import React, { useEffect, useMemo, useState } from 'react';
import { API_URL, createReport, getStats, healthCheck, sendContact, trackReport, uploadEvidence } from './api';

const sectors = [
  { key: 'education', label: 'Ta’lim', icon: '🎓' },
  { key: 'medicine', label: 'Tibbiyot', icon: '🏥' },
  { key: 'construction', label: 'Qurilish', icon: '🏗️' },
  { key: 'sport', label: 'Sport', icon: '⚽' },
  { key: 'publicServices', apiKey: 'public', label: 'Davlat xizmatlari', icon: '🏛️' },
  { key: 'transport', label: 'Transport', icon: '🚌' },
  { key: 'procurement', label: 'Davlat xaridlari', icon: '📦' },
];

const fallbackRegions = [
  { region: 'Tashkent', risk_score: 82, risk_level: 'Critical', reports: 142, top_sector: 'education', trend: '+28%', avg_response_time_days: 11, pattern: 'Imtihon va qabul jarayonida norasmiy to‘lovlar' },
  { region: 'Fergana', risk_score: 74, risk_level: 'High', reports: 118, top_sector: 'medicine', trend: '+19%', avg_response_time_days: 13, pattern: 'Bepul tibbiy xizmat uchun qo‘shimcha to‘lov so‘rash' },
  { region: 'Samarkand', risk_score: 67, risk_level: 'High', reports: 96, top_sector: 'construction', trend: '+12%', avg_response_time_days: 10, pattern: 'Ruxsatnoma va qurilish hujjatlarida tezlashtirish to‘lovlari' },
  { region: 'Andijan', risk_score: 59, risk_level: 'Medium', reports: 88, top_sector: 'publicServices', trend: '+8%', avg_response_time_days: 12, pattern: 'Davlat xizmatlarida navbatni tezlashtirish so‘rovlari' },
  { region: 'Namangan', risk_score: 54, risk_level: 'Medium', reports: 73, top_sector: 'transport', trend: '+6%', avg_response_time_days: 9, pattern: 'Litsenziya va yo‘nalish ruxsatnomalari' },
  { region: 'Bukhara', risk_score: 47, risk_level: 'Medium', reports: 61, top_sector: 'procurement', trend: '-2%', avg_response_time_days: 8, pattern: 'Bir xil yetkazib beruvchi takrorlanishi' },
  { region: 'Khorezm', risk_score: 36, risk_level: 'Low', reports: 39, top_sector: 'sport', trend: '-5%', avg_response_time_days: 7, pattern: 'Tanlov va saralashda tanish-bilishchilik xavfi' },
  { region: 'Karakalpakstan', risk_score: 41, risk_level: 'Medium', reports: 35, top_sector: 'publicServices', trend: '+3%', avg_response_time_days: 6, pattern: 'Hujjatlarni ko‘rib chiqishdagi kechikishlar' },
  { region: 'Kashkadarya', risk_score: 71, risk_level: 'High', reports: 84, top_sector: 'construction', trend: '+16%', avg_response_time_days: 14, pattern: 'Tender shartlari bitta kompaniyaga mos yozilgani haqidagi signallar' },
  { region: 'Surkhandarya', risk_score: 45, risk_level: 'Medium', reports: 42, top_sector: 'medicine', trend: '+4%', avg_response_time_days: 10, pattern: 'Dori va xizmat uchun norasmiy to‘lovlar' },
  { region: 'Jizzakh', risk_score: 33, risk_level: 'Low', reports: 28, top_sector: 'education', trend: '-1%', avg_response_time_days: 6, pattern: 'Kirish imtihoniga oid savollar' },
  { region: 'Sirdarya', risk_score: 30, risk_level: 'Low', reports: 22, top_sector: 'transport', trend: '+2%', avg_response_time_days: 5, pattern: 'Ruxsatnoma jarayonidagi noaniqliklar' },
  { region: 'Navoi', risk_score: 49, risk_level: 'Medium', reports: 48, top_sector: 'procurement', trend: '+7%', avg_response_time_days: 9, pattern: 'Xarid narxlari va muddatlaridagi noaniqlik' },
];

const lessons = [
  {
    title: 'Korrupsiya nima?', icon: '⚠️', time: '3 min', badge: 'Beginner',
    short: 'Vakolat yoki jamoat resursidan shaxsiy manfaat uchun foydalanish.',
    points: ['Korrupsiya faqat pora emas', 'Tanish-bilishchilik ham risk bo‘lishi mumkin', 'Report faktlarga asoslanishi kerak'],
    example: 'Davlat xodimi bepul xizmatni bajarish uchun norasmiy to‘lov so‘rasa, bu korrupsiya riski bo‘lishi mumkin.',
    quiz: [
      { q: 'Korrupsiya faqat pul olishmi?', a: ['Ha', 'Yo‘q', 'Faqat sovg‘a'], correct: 1 },
      { q: 'Report uchun nima muhim?', a: ['Fakt, vaqt, joy', 'Faqat emotsiya', 'Faqat ism'], correct: 0 },
      { q: 'AI yakuniy hukm chiqaradimi?', a: ['Ha', 'Yo‘q', 'Har doim'], correct: 1 },
    ],
  },
  {
    title: 'Nega korrupsiya zarar?', icon: '📉', time: '4 min', badge: 'Beginner',
    short: 'Budjet, adolat, xizmat sifati va davlatga ishonchga zarar yetkazadi.',
    points: ['Xizmat sifati pasayadi', 'Halol odamlar imkoniyatdan chetda qoladi', 'Budjet mablag‘i samarasiz sarflanadi'],
    example: 'Qurilishdagi korrupsiya sifatsiz maktab yoki yo‘l qurilishiga olib kelishi mumkin.',
    quiz: [
      { q: 'Korrupsiya kimga zarar?', a: ['Faqat davlatga', 'Jamiyatga', 'Hech kimga'], correct: 1 },
      { q: 'Kichik pora odatga aylansa?', a: ['Muammo kengayadi', 'Yaxshi bo‘ladi', 'Farqi yo‘q'], correct: 0 },
      { q: 'Dalilli signal nima beradi?', a: ['Riskni erta ko‘rsatadi', 'Spamni oshiradi', 'Faqat badge beradi'], correct: 0 },
    ],
  },
  {
    title: 'Qanday aniqlash?', icon: '🔎', time: '4 min', badge: 'Responsible Reporter',
    short: 'Norasmiy to‘lov, tanish orqali hal qilish, manfaatlar to‘qnashuvini tanish.',
    points: ['“Tezlashtirib beraman” kabi so‘zlar risk', 'Tender shartlari juda tor bo‘lsa risk', 'Bepul xizmat uchun pul so‘ralsa risk'],
    example: 'Tender talablari faqat bitta kompaniya mahsulotiga mos yozilgan bo‘lsa, bu signal bo‘lishi mumkin.',
    quiz: [
      { q: 'Bepul xizmat uchun pul so‘rash riskmi?', a: ['Ha', 'Yo‘q', 'Faqat kichik summa bo‘lsa yo‘q'], correct: 0 },
      { q: 'Manfaatlar to‘qnashuvi nima?', a: ['Qarindoshiga adolatsiz imkon berish', 'Navbatda turish', 'Ariza yozish'], correct: 0 },
      { q: 'Risk ko‘rsangiz nima qilasiz?', a: ['Fakt bilan report', 'Haqorat', 'Isbotsiz post'], correct: 0 },
    ],
  },
  {
    title: 'Xavfsiz report qilish', icon: '🛡️', time: '5 min', badge: 'Responsible Reporter',
    short: 'Faktlarga tayaning, o‘zingizni xavfga qo‘ymang, provokatsiya qilmang.',
    points: ['Anonim rejimdan foydalanish mumkin', 'Noqonuniy dalil yig‘mang', 'Nozik ma’lumotlarni ochiq tarqatmang'],
    example: '“Falon sanada, falon joyda, falon xizmat uchun norasmiy to‘lov so‘raldi” kabi yozish foydaliroq.',
    quiz: [
      { q: 'Noqonuniy provokatsiya mumkinmi?', a: ['Ha', 'Yo‘q', 'Ba’zida'], correct: 1 },
      { q: 'Report qanday bo‘lishi kerak?', a: ['Aniq va xolis', 'Haqoratli', 'Mish-mish'], correct: 0 },
      { q: 'Xavf bo‘lsa?', a: ['Anonim va ehtiyotkorlik', 'Ochiq e’lon', 'Provokatsiya'], correct: 0 },
    ],
  },
  {
    title: 'Dalil yo‘riqnomasi', icon: '📄', time: '4 min', badge: 'Evidence Builder',
    short: 'Foto, video, audio, hujjat, screenshot va rasmiy havolalar tekshiruvga yordam beradi.',
    points: ['Asl faylni saqlang', 'Sana va manba ko‘rinsin', 'Soxta yoki montaj dalil yubormang'],
    example: 'Tender ID, lot raqami, g‘olib kompaniya va rasmiy havola kuchli dalil bo‘lishi mumkin.',
    quiz: [
      { q: 'Qaysi dalil foydali?', a: ['Hujjat va screenshot', 'Emotsiya', 'Begona rasm'], correct: 0 },
      { q: 'Faylni montaj qilish kerakmi?', a: ['Yo‘q', 'Ha', 'Har doim'], correct: 0 },
      { q: 'Dalil yakuniy hukmmi?', a: ['Yo‘q, tekshiruvga yordam', 'Ha', 'Har doim'], correct: 0 },
    ],
  },
  {
    title: 'Reward system', icon: '🎁', time: '5 min', badge: 'Verified Contributor',
    short: 'Foydali, dalilli va real tekshiruvga yordam bergan ma’lumot reward reviewga o‘tadi.',
    points: ['Report foydali bo‘lishi kerak', 'Yolg‘on bo‘lmasligi kerak', 'Case outcome muhim'],
    example: 'Xabar asosida rasmiy tekshiruv boshlansa yoki xavfli pattern aniqlansa, reward review mumkin.',
    quiz: [
      { q: 'Reward nimaga beriladi?', a: ['Foydali ma’lumotga', 'Ko‘p spamga', 'Haqoratga'], correct: 0 },
      { q: 'Yolg‘on report reward oladimi?', a: ['Yo‘q', 'Ha', 'Ba’zida'], correct: 0 },
      { q: 'Reward qachon ko‘riladi?', a: ['Tekshiruvdan keyin', 'Darhol', 'Formani ochganda'], correct: 0 },
    ],
  },
];

const statusSteps = [
  { key: 'SUBMITTED', label: 'Submitted', text: 'Report xavfsiz qabul qilindi.' },
  { key: 'AI_CHECKED', label: 'AI checked', text: 'AI struktura, risk va to‘liqlikni baholadi.' },
  { key: 'MODERATOR_REVIEWING', label: 'Moderator review', text: 'Moderator faktlarni tekshirmoqda.' },
  { key: 'MORE_EVIDENCE_NEEDED', label: 'More info needed', text: 'Qo‘shimcha dalil yoki aniqlik kerak.' },
  { key: 'SENT_TO_AGENCY', label: 'Sent to agency', text: 'Mas’ul organga yuborildi.' },
  { key: 'AGENCY_DEADLINE_STARTED', label: 'Response deadline', text: 'Agentlik javob muddati boshlandi.' },
  { key: 'CONFIRMED', label: 'Confirmed / Not', text: 'Natija rasmiy ko‘rib chiqildi.' },
  { key: 'REWARD_REVIEW', label: 'Reward review', text: 'Mukofot imkoniyati tekshirilmoqda.' },
  { key: 'CLOSED', label: 'Closed', text: 'Case yopildi.' },
];

const riskClass = { Low: 'risk-low', Medium: 'risk-medium', High: 'risk-high', Critical: 'risk-critical' };
const sectorLabel = (key) => sectors.find(s => s.key === key || s.apiKey === key)?.label || key || 'Ta’lim';

function normalizeRisk(level, score) {
  if (level) return level;
  if (score >= 80) return 'Critical';
  if (score >= 60) return 'High';
  if (score >= 35) return 'Medium';
  return 'Low';
}

function localAnalyze(report) {
  const text = `${report.description || ''} ${report.category || ''}`.toLowerCase();
  let score = 22;
  const suggestions = [];
  if ((report.description || '').length > 120) score += 22; else suggestions.push('Tavsifga aniq vaqt, joy va nima so‘ralganini qo‘shing.');
  if (report.location) score += 14; else suggestions.push('Joylashuvni qo‘shing.');
  if (report.organization) score += 14; else suggestions.push('Tashkilot nomini kiriting.');
  if (report.incident_date) score += 8;
  if (report.has_evidence) score += 22; else suggestions.push('Agar xavfsiz bo‘lsa, dalil fayl qo‘shing.');
  if (/(pora|pul|tender|otkat|to‘lov|tolov|sovg|tanish)/i.test(text)) score += 10;
  score = Math.min(score, 96);
  return {
    risk_score: score,
    category: report.category,
    urgency: report.danger_flag || score >= 80 ? 'High' : score >= 55 ? 'Medium' : 'Low',
    evidence_strength: report.has_evidence ? (score >= 70 ? 'High' : 'Medium') : 'Low',
    completeness: Math.min(100, score + (report.has_evidence ? 3 : -8)),
    reward_potential: score >= 70 && report.has_evidence ? 'possible' : 'not_eligible_yet',
    suggestions,
    next_step: 'Moderator review',
    ai_mode: 'frontend_fallback',
  };
}

function saveLocalReport(report) {
  const reports = JSON.parse(localStorage.getItem('cs_reports') || '[]');
  localStorage.setItem('cs_reports', JSON.stringify([report, ...reports.filter(r => r.tracking_id !== report.tracking_id)]));
}

function getLocalReports() {
  try { return JSON.parse(localStorage.getItem('cs_reports') || '[]'); } catch { return []; }
}

function statusIndex(status) {
  const index = statusSteps.findIndex(s => s.key === status);
  return index >= 0 ? index : 1;
}

function App() {
  const [active, setActive] = useState('map');
  const [apiOnline, setApiOnline] = useState('checking');
  const [stats, setStats] = useState(null);
  const [selectedSector, setSelectedSector] = useState('all');
  const [selectedRegion, setSelectedRegion] = useState('Tashkent');
  const [selectedLesson, setSelectedLesson] = useState(0);
  const [completed, setCompleted] = useState(() => JSON.parse(localStorage.getItem('cs_lessons') || '{}'));
  const [answers, setAnswers] = useState({});
  const [quizScore, setQuizScore] = useState(null);
  const [report, setReport] = useState({ category: 'education', description: '', location: '', incident_date: '', organization: '', requested: '', anonymous: true, danger_flag: false, file: null });
  const [submitState, setSubmitState] = useState({ loading: false, error: '', result: null });
  const [trackId, setTrackId] = useState('');
  const [tracked, setTracked] = useState(null);
  const [trackError, setTrackError] = useState('');
  const [contact, setContact] = useState({ name: '', email: '', question_type: 'report question', message: '' });

  useEffect(() => {
    healthCheck().then(() => setApiOnline('online')).catch(() => setApiOnline('offline'));
    getStats().then(setStats).catch(() => setStats(null));
  }, []);

  const regions = stats?.regions?.length ? stats.regions : fallbackRegions;
  const pickedRegion = regions.find(r => r.region === selectedRegion) || regions[0];
  const filteredRegions = useMemo(() => {
    if (selectedSector === 'all') return regions;
    return [...regions].sort((a, b) => (b.top_sector === selectedSector ? 1 : 0) - (a.top_sector === selectedSector ? 1 : 0) || b.risk_score - a.risk_score);
  }, [regions, selectedSector]);

  const localAi = useMemo(() => localAnalyze({
    category: report.category,
    description: `${report.description} ${report.requested}`,
    location: report.location,
    organization: report.organization,
    incident_date: report.incident_date,
    has_evidence: Boolean(report.file),
    danger_flag: report.danger_flag,
  }), [report]);

  const writingSuggestion = useMemo(() => {
    if (!report.description || report.description.length < 35) return 'Please add where, when, what happened, and what was requested.';
    if (/poraxo‘r|poraxor|jinoyatchi|o‘g‘ri|ogri|ahmoq/i.test(report.description)) return 'Try to describe facts calmly. Avoid insults or unsupported accusations.';
    if (!report.location) return 'Good start. Add location so moderators can route the report correctly.';
    if (!report.organization) return 'Add the organization name if you know it.';
    return 'Good structure. Evidence can improve verification and reward review.';
  }, [report]);

  const progress = Math.round((Object.values(completed).filter(Boolean).length / lessons.length) * 100);

  async function submitReport() {
    setSubmitState({ loading: true, error: '', result: null });
    const payload = {
      category: report.category,
      description: `${report.description}\n\nRequested/offered: ${report.requested || 'Not specified'}`,
      location: report.location,
      region: report.location || 'Tashkent',
      organization: report.organization,
      incident_date: report.incident_date || null,
      anonymous: report.anonymous,
      danger_flag: report.danger_flag,
      has_evidence: Boolean(report.file),
    };
    try {
      let created = await createReport(payload);
      if (report.file && created?.report?.id) {
        try { created.report = await uploadEvidence(created.report.id, report.file); } catch (e) { console.warn('Evidence upload failed:', e.message); }
      }
      const ai = created.ai_result || created.report?.ai_result || localAnalyze(payload);
      const normalized = { ...created.report, tracking_id: created.tracking_id || created.report?.tracking_id, ai_result: ai, status: created.status || created.report?.status || 'AI_CHECKED' };
      saveLocalReport(normalized);
      setSubmitState({ loading: false, error: '', result: normalized });
      setTrackId(normalized.tracking_id || '');
      setTracked(normalized);
      setActive('track');
      getStats().then(setStats).catch(() => {});
    } catch (error) {
      const fallback = {
        id: Date.now(),
        tracking_id: `CS-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 999999)).padStart(6, '0')}`,
        ...payload,
        status: 'AI_CHECKED',
        ai_score: localAi.risk_score,
        ai_result: localAi,
        reward_status: localAi.reward_potential,
        created_at: new Date().toISOString(),
        messages: [{ sender: 'System', message: 'Backend offline: report saved locally for demo.' }],
        timeline: statusSteps.slice(0, 2).map(s => ({ status: s.key, title: s.label, description: s.text, created_at: new Date().toISOString() })),
      };
      saveLocalReport(fallback);
      setSubmitState({ loading: false, error: `Backend ishlamadi, local demo mode: ${error.message}`, result: fallback });
      setTrackId(fallback.tracking_id);
      setTracked(fallback);
      setActive('track');
    }
  }

  async function findReport() {
    setTrackError('');
    setTracked(null);
    try {
      const data = await trackReport(trackId);
      setTracked(data);
      saveLocalReport(data);
    } catch (error) {
      const local = getLocalReports().find(r => r.tracking_id?.toLowerCase() === trackId.trim().toLowerCase());
      if (local) setTracked(local); else setTrackError('Report topilmadi. Tracking ID ni tekshiring.');
    }
  }

  function checkQuiz() {
    const lesson = lessons[selectedLesson];
    let correct = 0;
    lesson.quiz.forEach((q, i) => { if (answers[`${selectedLesson}-${i}`] === q.correct) correct += 1; });
    const score = Math.round((correct / lesson.quiz.length) * 100);
    setQuizScore(score);
    if (score >= 60) {
      const next = { ...completed, [selectedLesson]: true };
      setCompleted(next);
      localStorage.setItem('cs_lessons', JSON.stringify(next));
    }
  }

  const nav = [
    ['map', 'Corruption Map', '📍'], ['learn', 'Learn & Earn', '📚'], ['report', 'Send Report', '⬆️'], ['track', 'Track My Report', '⏱️'], ['contact', 'Contact & FAQ', '☎️']
  ];

  return <main className="app">
    <Header nav={nav} active={active} setActive={setActive} apiOnline={apiOnline} />
    <Hero setActive={setActive} />
    <div className="container">
      {active === 'map' && <MapSection stats={stats} regions={filteredRegions} pickedRegion={pickedRegion} selectedRegion={selectedRegion} setSelectedRegion={setSelectedRegion} selectedSector={selectedSector} setSelectedSector={setSelectedSector} setActive={setActive} />}
      {active === 'learn' && <LearnSection selectedLesson={selectedLesson} setSelectedLesson={setSelectedLesson} completed={completed} progress={progress} answers={answers} setAnswers={setAnswers} quizScore={quizScore} setQuizScore={setQuizScore} checkQuiz={checkQuiz} />}
      {active === 'report' && <ReportSection report={report} setReport={setReport} localAi={localAi} writingSuggestion={writingSuggestion} submitState={submitState} submitReport={submitReport} />}
      {active === 'track' && <TrackSection trackId={trackId} setTrackId={setTrackId} tracked={tracked} trackError={trackError} findReport={findReport} setActive={setActive} />}
      {active === 'contact' && <ContactSection contact={contact} setContact={setContact} />}
    </div>
    <footer className="footer"><b>CleanSignal</b><span>AI assists analysis. Final decisions are made by human reviewers.</span></footer>
  </main>;
}

function Header({ nav, active, setActive, apiOnline }) {
  return <header className="topbar">
    <button className="brand" onClick={() => setActive('map')}><span>🛡️</span><div><b>CleanSignal</b><small>Civic intelligence platform</small></div></button>
    <nav>{nav.map(([id, label, icon]) => <button key={id} onClick={() => setActive(id)} className={active === id ? 'active' : ''}><span>{icon}</span>{label}</button>)}</nav>
    <div className={`api-pill ${apiOnline}`}><span></span>{apiOnline === 'online' ? 'Backend online' : apiOnline === 'offline' ? 'Local fallback' : 'Checking API'}</div>
  </header>;
}

function Hero({ setActive }) {
  return <section className="hero">
    <div className="hero-inner">
      <div>
        <div className="eyebrow">✨ Professional GovTech MVP</div>
        <h1>Korrupsiyaga qarshi kurashishni o‘rganing, xabar bering va kuzating.</h1>
        <p>CleanSignal fuqarolar va yoshlarni korrupsiya risklarini tushunish, dalil bilan xavfsiz report yuborish va real progressni kuzatishga jalb qiladi.</p>
        <div className="hero-actions"><button onClick={() => setActive('report')}>Xabar yuborish</button><button onClick={() => setActive('learn')} className="ghost">Reward qoidalari</button></div>
      </div>
      <div className="hero-card">
        <div className="card-head"><b>Live AI preview</b><span>Human review required</span></div>
        <div className="score-ring">81</div>
        <div className="mini-grid"><span>Risk score</span><b>81/100</b><span>Urgency</span><b>High</b><span>Reward</span><b>Possible</b></div>
      </div>
    </div>
    <div className="trust-row"><span>🔒 Anonymous reporting</span><span>📎 Evidence safety</span><span>🤖 AI assists</span><span>👤 Humans decide</span><span>⏱️ Transparent tracking</span></div>
  </section>;
}

function SectionTitle({ icon, eyebrow, title, subtitle }) {
  return <div className="section-title"><div className="eyebrow dark"><span>{icon}</span>{eyebrow}</div><h2>{title}</h2><p>{subtitle}</p></div>;
}

function MapSection({ stats, regions, pickedRegion, selectedRegion, setSelectedRegion, selectedSector, setSelectedSector, setActive }) {
  const total = stats?.total_reports ?? regions.reduce((s, r) => s + (r.reports || 0), 0);
  const verified = stats?.verified_signals ?? 312;
  const high = stats?.high_risk_regions ?? regions.filter(r => ['High', 'Critical'].includes(normalizeRisk(r.risk_level, r.risk_score))).length;
  const avg = stats?.average_response_time_days ?? 9;
  const topSector = stats?.top_sector ?? 'education';
  return <section>
    <SectionTitle icon="📍" eyebrow="Corruption Map" title="Hudud va sektorlar bo‘yicha pro dashboard" subtitle="Bu bo‘lim static xarita emas: hudud risklari, sector filter, trend, agency response va AI insight bir joyda ko‘rinadi." />
    <div className="stats-grid"><Stat label="Total reports" value={total.toLocaleString?.() || total} icon="📄" /><Stat label="Verified signals" value={verified} icon="✅" /><Stat label="High-risk regions" value={high} icon="⚠️" /><Stat label="Avg response time" value={`${avg} days`} icon="⏱️" /><Stat label="Top sector" value={sectorLabel(topSector)} icon="📊" /></div>
    <div className="filters"><button className={selectedSector === 'all' ? 'active' : ''} onClick={() => setSelectedSector('all')}>All sectors</button>{sectors.map(s => <button key={s.key} onClick={() => setSelectedSector(s.key)} className={selectedSector === s.key ? 'active' : ''}>{s.icon} {s.label}</button>)}</div>
    <div className="map-layout">
      <div className="map-card"><div className="map-head"><div><h3>Uzbekistan risk map</h3><p>Region card bosilganda detail panel yangilanadi.</p></div><Legend /></div><div className="region-grid">{regions.map(r => { const level = normalizeRisk(r.risk_level, r.risk_score); return <button key={r.region} onClick={() => setSelectedRegion(r.region)} className={`region ${riskClass[level]} ${selectedRegion === r.region ? 'selected' : ''}`}><span>📍</span><b>{r.region}</b><strong>{r.risk_score}/100</strong><small>{level} · {r.reports} reports</small></button>; })}</div></div>
      <aside className="detail-card"><div className="detail-top"><h3>{pickedRegion.region}</h3><span className={`risk-badge ${riskClass[normalizeRisk(pickedRegion.risk_level, pickedRegion.risk_score)]}`}>{normalizeRisk(pickedRegion.risk_level, pickedRegion.risk_score)}</span></div><Info label="Risk score" value={`${pickedRegion.risk_score}/100`} /><Info label="Report count" value={pickedRegion.reports || 0} /><Info label="Trend" value={pickedRegion.trend || '+12%'} /><Info label="Top sector" value={sectorLabel(pickedRegion.top_sector)} /><Info label="Avg response" value={`${pickedRegion.avg_response_time_days || 9} days`} /><Info label="Corruption pattern" value={pickedRegion.pattern || 'Unofficial payment and routing risk'} /><button className="full" onClick={() => setActive('report')}>Report here</button></aside>
    </div>
    <div className="ai-insight"><b>🤖 AI Insight</b><p>{stats?.ai_insight || 'Reports in education increased by 28% this month. Highest growth: Tashkent region. Common issue: exam-related payments. Recommendation: prioritize evidence-based reports with organization names.'}</p></div>
  </section>;
}

function LearnSection({ selectedLesson, setSelectedLesson, completed, progress, answers, setAnswers, quizScore, setQuizScore, checkQuiz }) {
  const lesson = lessons[selectedLesson];
  return <section>
    <SectionTitle icon="📚" eyebrow="Learn & Earn" title="Interaktiv mini darslar va reward guide" subtitle="Har bir dars qisqa tushuntirish, key points, example va 3 savolli quizdan iborat." />
    <div className="learn-layout"><aside><div className="progress-card"><b>Learning progress</b><strong>{progress}%</strong><div className="progress"><span style={{ width: `${progress}%` }} /></div><p>Badges: Beginner → Responsible Reporter → Verified Contributor</p></div>{lessons.map((l, i) => <button key={l.title} onClick={() => { setSelectedLesson(i); setQuizScore(null); }} className={`lesson-tab ${selectedLesson === i ? 'active' : ''}`}><span>{l.icon}</span><div><b>{l.title}</b><small>{l.time} · {l.badge}</small></div>{completed[i] && <em>✓</em>}</button>)}</aside>
      <div className="lesson-panel"><div className="lesson-head"><span>{lesson.icon}</span><div><h3>{lesson.title}</h3><p>{lesson.short}</p></div></div><div className="lesson-box"><h4>Key points</h4>{lesson.points.map(p => <p key={p}>✓ {p}</p>)}</div><div className="lesson-box"><h4>Example</h4><p>{lesson.example}</p></div><div className="quiz-box"><h4>Mini quiz</h4>{lesson.quiz.map((q, qi) => <div key={q.q} className="question"><b>{qi + 1}. {q.q}</b>{q.a.map((a, ai) => <button key={a} onClick={() => setAnswers({ ...answers, [`${selectedLesson}-${qi}`]: ai })} className={answers[`${selectedLesson}-${qi}`] === ai ? 'picked' : ''}>{a}</button>)}</div>)}<button onClick={checkQuiz} className="full">Check quiz</button>{quizScore !== null && <div className={quizScore >= 60 ? 'success' : 'warn'}>Natija: {quizScore}% {quizScore >= 60 ? '— lesson completed.' : '— retry needed.'}</div>}</div></div>
    </div><RewardGuide />
  </section>;
}

function RewardGuide() {
  const blocks = [
    ['Valuable report', ['specific', 'detailed', 'real situation', 'includes context']],
    ['Accepted evidence', ['photo', 'video', 'audio', 'document', 'screenshots']],
    ['Process', ['Submit', 'AI check', 'Moderator', 'Agency', 'Result', 'Reward review']],
    ['Reward conditions', ['useful information', 'not fake', 'helps investigation', 'case outcome matters']],
    ['Rejection reasons', ['vague', 'no facts', 'emotional accusations', 'fake evidence', 'spam']],
  ];
  return <div className="reward"><h3>🔥 Reward system — eng muhim qism</h3><div className="reward-grid">{blocks.map(([title, items]) => <div key={title}><b>{title}</b>{items.map(i => <p key={i}>✓ {i}</p>)}</div>)}</div></div>;
}

function ReportSection({ report, setReport, localAi, writingSuggestion, submitState, submitReport }) {
  const [step, setStep] = useState(0);
  const steps = ['Category', 'Description', 'Location & time', 'Organization', 'Evidence', 'Safety', 'Review'];
  const set = (k, v) => setReport({ ...report, [k]: v });
  return <section>
    <SectionTitle icon="⬆️" eyebrow="Send Report" title="Smart UX bilan step-based report form" subtitle="Userni yo‘naltiradi: nima bo‘ldi, qayerda, qachon, qaysi tashkilot, dalil, anonimlik va safety." />
    <div className="report-layout"><aside className="stepper">{steps.map((s, i) => <button key={s} onClick={() => setStep(i)} className={i === step ? 'active' : i < step ? 'done' : ''}><span>{i + 1}</span>{s}</button>)}</aside><div className="form-panel">
      {step === 0 && <div><h3>Category</h3><div className="category-grid">{sectors.map(s => <button key={s.key} onClick={() => set('category', s.key)} className={report.category === s.key ? 'active' : ''}>{s.icon}<b>{s.label}</b></button>)}</div></div>}
      {step === 1 && <div><h3>What happened?</h3><textarea value={report.description} onChange={e => set('description', e.target.value)} placeholder="Masalan: Tender talablari faqat bitta kompaniya uchun yozilgandek ko‘rinadi..." /><div className="assistant"><b>🤖 AI Writing Assistant</b><p>{writingSuggestion}</p></div></div>}
      {step === 2 && <div><h3>Location & time</h3><input value={report.location} onChange={e => set('location', e.target.value)} placeholder="Where? e.g. Tashkent" /><input type="date" value={report.incident_date} onChange={e => set('incident_date', e.target.value)} /></div>}
      {step === 3 && <div><h3>Organization</h3><input value={report.organization} onChange={e => set('organization', e.target.value)} placeholder="Which organization?" /><input value={report.requested} onChange={e => set('requested', e.target.value)} placeholder="What was requested or offered?" /></div>}
      {step === 4 && <div><h3>Evidence upload</h3><label className="drop"><input type="file" onChange={e => set('file', e.target.files?.[0] || null)} /><span>📎 Drag & drop / click to upload</span><small>photo, video, audio, document, screenshots. Do not risk your safety to collect evidence.</small></label>{report.file && <div className="success">Selected: {report.file.name}</div>}</div>}
      {step === 5 && <div><h3>Safety</h3><Toggle label="Anonymous?" value={report.anonymous} onChange={v => set('anonymous', v)} /><Toggle label="Are you in danger?" value={report.danger_flag} onChange={v => set('danger_flag', v)} /><div className="warn">⚠ Do not risk your safety to collect evidence. AI assists analysis; final decisions are made by human reviewers.</div></div>}
      {step === 6 && <div><h3>Review</h3><Info label="Category" value={sectorLabel(report.category)} /><Info label="Where" value={report.location || '—'} /><Info label="When" value={report.incident_date || '—'} /><Info label="Organization" value={report.organization || '—'} /><Info label="Evidence" value={report.file ? report.file.name : 'No file'} /><div className="local-ai"><b>Local AI preview</b><span>Risk {localAi.risk_score}/100 · {localAi.urgency} · completeness {localAi.completeness}%</span></div></div>}
      <div className="form-actions"><button disabled={step === 0} onClick={() => setStep(Math.max(0, step - 1))}>Back</button>{step < steps.length - 1 ? <button onClick={() => setStep(step + 1)}>Next</button> : <button onClick={submitReport} disabled={submitState.loading}>{submitState.loading ? 'Sending...' : 'Submit safely'}</button>}</div>{submitState.error && <div className="warn">{submitState.error}</div>}
    </div></div>
  </section>;
}

function TrackSection({ trackId, setTrackId, tracked, trackError, findReport, setActive }) {
  const ai = tracked?.ai_result || {};
  const current = statusIndex(tracked?.status);
  return <section>
    <SectionTitle icon="⏱️" eyebrow="Track My Report" title="Foydalanuvchi ignored bo‘lib qolmaydi" subtitle="Tracking ID orqali status, deadline, moderator messages, reward status va next step ko‘rinadi." />
    <div className="track-search"><input value={trackId} onChange={e => setTrackId(e.target.value)} placeholder="CS-2026-000123" /><button onClick={findReport}>Find report</button><button className="ghost-btn" onClick={() => setActive('report')}>New report</button></div>{trackError && <div className="warn">{trackError}</div>}
    {tracked ? <div className="track-layout"><aside className="track-card"><h3>{tracked.tracking_id}</h3><Info label="Risk score" value={`${ai.risk_score ?? tracked.ai_score ?? 0}/100`} /><Info label="Category" value={sectorLabel(ai.category || tracked.category)} /><Info label="Urgency" value={ai.urgency || 'Medium'} /><Info label="Evidence strength" value={ai.evidence_strength || 'Low'} /><Info label="Completeness" value={`${ai.completeness || 0}%`} /><Info label="Reward status" value={tracked.reward_status || ai.reward_potential || 'not eligible'} /><div className="deadline"><b>Deadlines</b><p>Moderator review: 2–3 days</p><p>Agency response: 15 working days</p></div><div className="impact"><b>Impact card</b><p>You submitted: 1 report</p><p>Under review: {current < 8 ? 1 : 0}</p><p>Potential impact: {Number(ai.risk_score || 0) >= 70 ? 'High' : 'Medium'}</p></div></aside><div className="timeline">{statusSteps.map((s, i) => <div key={s.key} className={i <= current ? 'on' : ''}><span>{i < current ? '✓' : i === current ? '⏱' : i + 1}</span><div><b>{s.label}</b><p>{i === current ? 'Current step: ' : ''}{s.text}</p></div></div>)}<div className="messages"><b>Moderator messages</b>{(tracked.messages?.length ? tracked.messages : [{ sender: 'System', message: 'Your report is under moderator review. Estimated time: 2–3 days.' }]).map((m, i) => <p key={i}><strong>{m.sender}:</strong> {m.message}</p>)}</div></div></div> : <div className="empty">Tracking ID kiriting yoki report yuboring.</div>}
  </section>;
}

function ContactSection({ contact, setContact }) {
  const [sent, setSent] = useState('');
  async function submit(e) {
    e.preventDefault();
    try { await sendContact(contact); setSent('Xabar qabul qilindi.'); } catch { setSent('Demo: xabar local ko‘rinishda qabul qilindi.'); }
  }
  const faqs = ['Is my identity safe?', 'Can I stay anonymous?', 'What evidence is valid?', 'Can I get a reward?', 'How long does it take?'];
  return <section><SectionTitle icon="☎️" eyebrow="Contact & FAQ" title="Savollar uchun aloqa" subtitle="Foydalanuvchi reward, xavfsizlik, dalil va tracking bo‘yicha javob olishi kerak." /><div className="contact-layout"><div>{faqs.map(q => <details key={q}><summary>{q}</summary><p>CleanSignal anonim report, evidence safety va human review prinsiplariga asoslanadi. AI faqat yordamchi tahlil qiladi.</p></details>)}</div><form onSubmit={submit}><input placeholder="Name optional" value={contact.name} onChange={e => setContact({ ...contact, name: e.target.value })} /><input placeholder="Email" value={contact.email} onChange={e => setContact({ ...contact, email: e.target.value })} /><select value={contact.question_type} onChange={e => setContact({ ...contact, question_type: e.target.value })}><option>technical issue</option><option>report question</option><option>reward question</option><option>safety concern</option><option>other</option></select><textarea placeholder="Message" value={contact.message} onChange={e => setContact({ ...contact, message: e.target.value })} /><button>Send message</button>{sent && <div className="success">{sent}</div>}<p className="contact-info">Hotline: +998 XX XXX XX XX<br />Email: support@cleansignal.uz</p></form></div></section>;
}

function Stat({ label, value, icon }) { return <div className="stat"><span>{icon}</span><b>{value}</b><small>{label}</small></div>; }
function Info({ label, value }) { return <div className="info"><span>{label}</span><b>{value}</b></div>; }
function Legend() { return <div className="legend"><span><i className="low"></i>Low</span><span><i className="medium"></i>Medium</span><span><i className="high"></i>High</span><span><i className="critical"></i>Critical</span></div>; }
function Toggle({ label, value, onChange }) { return <label className="toggle"><span>{label}</span><button type="button" onClick={() => onChange(!value)} className={value ? 'yes' : ''}><i /></button></label>; }

export default App;
