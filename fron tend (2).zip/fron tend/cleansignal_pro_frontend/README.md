# CleanSignal Pro Frontend

Bu frontend siz bergan MVP prompt asosida qurilgan:

- Corruption Map pro dashboard
- Learn & Earn mini lessons + quiz + reward guide
- Send Report step-based smart UX
- AI Writing Assistant
- Backend AI result card
- Track My Report real backend search
- Contact & FAQ
- localStorage fallback

## 1) Backendni ishga tushirish

Sizdagi FastAPI backend ishlashi kerak:

```powershell
cd cleansignal-backend-ideal
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Tekshir:

```text
http://127.0.0.1:8000/docs
```

## 2) Frontendni ishga tushirish

```powershell
cd cleansignal_pro_frontend
copy .env.example .env
npm install
npm run dev
```

Odatda ochiladi:

```text
http://localhost:5173
```

## 3) API URL

`.env` ichida:

```env
VITE_API_URL=http://127.0.0.1:8000
```

## 4) Backend ai_result bug patch

Agar backend `POST /reports` da `500 Internal Server Error` bersa va logda `ai_result Input should be a valid dictionary` chiqsa, backenddagi `app/routers/reports.py` ichida `_report_to_out` funksiyasini quyidagiga almashtiring:

```python
def _report_to_out(report: Report) -> ReportOut:
    if isinstance(report.ai_result, str) and report.ai_result:
        try:
            report.ai_result = json.loads(report.ai_result)
        except Exception:
            report.ai_result = None
    return ReportOut.model_validate(report)
```

Yoki `models.py` da `ai_result` ustunini Text emas JSON qilib saqlang.

## 5) Ishlash flow

1. Corruption Map backend `/stats` dan data oladi, bo‘lmasa fallback mock data ishlaydi.
2. Send Report `POST /reports` ga yuboradi.
3. Agar file tanlansa, `POST /reports/{id}/evidence` qiladi.
4. Backend AI result qaytaradi.
5. Tracking ID localStorage’da saqlanadi.
6. Track My Report `GET /reports/track/{tracking_id}` dan qidiradi.

## 6) Demo uchun muhim

Backend ishlamasa ham frontend local fallback bilan demo flowni buzmaydi, lekin haqiqiy backend integratsiya uchun backend online bo‘lishi kerak.
