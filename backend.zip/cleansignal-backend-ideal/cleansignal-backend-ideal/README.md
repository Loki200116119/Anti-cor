# CleanSignal Backend Ideal

FastAPI + SQLite backend for CleanSignal MVP.

## Features

- Create reports
- Generate tracking ID
- Rule-based AI scoring fallback
- Optional OpenAI AI analysis
- Evidence upload with SHA-256 hash
- Track report by tracking ID
- Admin/demo status update
- Moderator messages
- Map/statistics endpoint
- Contact form endpoint
- Swagger docs

## Quick Start Windows PowerShell

```powershell
cd cleansignal-backend-ideal
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload
```

Open:

```text
http://127.0.0.1:8000/docs
```

## Optional OpenAI AI

Edit `.env`:

```env
OPENAI_API_KEY=sk-your-key
USE_OPENAI_AI=true
OPENAI_MODEL=gpt-4.1-mini
```

If OpenAI fails or the key is missing, backend automatically uses rule-based AI.

## Main Endpoints

```text
GET    /health
POST   /reports
GET    /reports
GET    /reports/track/{tracking_id}
GET    /reports/{report_id}
PATCH  /reports/{report_id}/status
POST   /reports/{report_id}/messages
POST   /reports/{report_id}/evidence
GET    /stats
POST   /contact
```

## Create report example

```json
{
  "category": "education",
  "description": "School exam process may involve unofficial payment request. Parent was told documents would be processed faster for cash.",
  "location": "Tashkent",
  "region": "Tashkent",
  "organization": "Example school",
  "incident_date": "2026-04-25",
  "anonymous": true,
  "danger_flag": false,
  "contact": null,
  "has_evidence": false
}
```

## Connect React frontend

In your frontend, set API base URL:

```js
const API_BASE = "http://127.0.0.1:8000";
```

Create report:

```js
await fetch(`${API_BASE}/reports`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(report)
});
```

Track:

```js
await fetch(`${API_BASE}/reports/track/${trackingId}`);
```
