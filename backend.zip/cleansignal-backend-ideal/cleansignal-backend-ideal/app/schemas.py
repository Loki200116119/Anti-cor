from datetime import datetime
from typing import Any
from pydantic import BaseModel, Field


class ReportCreate(BaseModel):
    category: str = Field(..., min_length=2, max_length=64)
    description: str = Field(..., min_length=10)
    location: str | None = None
    region: str | None = None
    organization: str | None = None
    incident_date: str | None = None
    anonymous: bool = True
    danger_flag: bool = False
    contact: str | None = None
    has_evidence: bool = False


class AIResult(BaseModel):
    risk_score: int
    category: str
    urgency: str
    evidence_strength: str
    completeness: int
    reward_potential: str
    suggestions: list[str]
    summary: str | None = None
    next_step: str
    ai_mode: str


class EvidenceOut(BaseModel):
    id: int
    original_name: str
    content_type: str | None
    size_bytes: int
    sha256: str
    created_at: datetime

    model_config = {"from_attributes": True}


class TimelineOut(BaseModel):
    status: str
    title: str
    description: str
    created_at: datetime

    model_config = {"from_attributes": True}


class MessageOut(BaseModel):
    sender: str
    message: str
    created_at: datetime

    model_config = {"from_attributes": True}


class ReportOut(BaseModel):
    id: int
    tracking_id: str
    category: str
    description: str
    location: str | None
    region: str | None
    organization: str | None
    incident_date: str | None
    anonymous: bool
    danger_flag: bool
    status: str
    ai_score: int
    ai_result: dict[str, Any] | None
    reward_status: str
    created_at: datetime
    updated_at: datetime
    evidence_files: list[EvidenceOut] = []
    timeline: list[TimelineOut] = []
    messages: list[MessageOut] = []

    model_config = {"from_attributes": True}


class ReportCreated(BaseModel):
    tracking_id: str
    status: str
    ai_result: dict[str, Any]
    report: ReportOut


class StatusUpdate(BaseModel):
    status: str
    message: str | None = None


class ModeratorMessageCreate(BaseModel):
    sender: str = "Moderator"
    message: str = Field(..., min_length=2)


class ContactCreate(BaseModel):
    name: str | None = None
    email: str = Field(..., min_length=5)
    question_type: str = "other"
    message: str = Field(..., min_length=5)


class ContactOut(BaseModel):
    id: int
    status: str = "received"
