import json
import os
from datetime import datetime
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import desc
from sqlalchemy.orm import Session, selectinload
from app.ai import analyze_report
from app.database import get_db
from app.models import EvidenceFile, ModeratorMessage, Report, TimelineEvent
from app.schemas import ModeratorMessageCreate, ReportCreate, ReportCreated, ReportOut, StatusUpdate
from app.utils import ensure_upload_dir, generate_tracking_id, safe_filename, sha256_bytes

router = APIRouter(prefix="/reports", tags=["reports"])

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "app/uploads")
MAX_FILE_SIZE = 25 * 1024 * 1024
ALLOWED_CONTENT_TYPES = {
    "image/jpeg",
    "image/png",
    "image/webp",
    "video/mp4",
    "audio/mpeg",
    "audio/wav",
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
}


def _load_report_or_404(db: Session, report_id: int) -> Report:
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return report


def _report_to_out(report: Report) -> ReportOut:
    data = ReportOut.model_validate(report)
    if isinstance(report.ai_result, str) and report.ai_result:
        try:
            data.ai_result = json.loads(report.ai_result)
        except Exception:
            data.ai_result = None
    return data


def add_timeline(db: Session, report: Report, status: str, title: str, description: str) -> None:
    db.add(TimelineEvent(report_id=report.id, status=status, title=title, description=description))


@router.post("", response_model=ReportCreated)
def create_report(payload: ReportCreate, db: Session = Depends(get_db)):
    tracking_id = generate_tracking_id()
    ai_result = analyze_report(payload.model_dump())

    report = Report(
        tracking_id=tracking_id,
        category=payload.category,
        description=payload.description,
        location=payload.location,
        region=payload.region,
        organization=payload.organization,
        incident_date=payload.incident_date,
        anonymous=payload.anonymous,
        danger_flag=payload.danger_flag,
        contact=payload.contact,
        status="AI_CHECKED",
        ai_score=int(ai_result.get("risk_score", 0)),
        ai_result=json.dumps(ai_result, ensure_ascii=False),
        reward_status=ai_result.get("reward_potential", "not_eligible_yet"),
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    add_timeline(db, report, "SUBMITTED", "Report submitted safely", "Your report was received by CleanSignal.")
    add_timeline(db, report, "AI_CHECKED", "AI structure check completed", "AI reviewed structure and risk signals. Human moderators make final decisions.")
    db.add(ModeratorMessage(report_id=report.id, sender="System", message="Your report is now ready for moderator review."))
    db.commit()
    db.refresh(report)

    loaded = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files)).filter(Report.id == report.id).first()
    return {"tracking_id": tracking_id, "status": loaded.status, "ai_result": ai_result, "report": _report_to_out(loaded)}


@router.get("", response_model=list[ReportOut])
def list_reports(status: str | None = None, limit: int = 50, db: Session = Depends(get_db)):
    query = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files))
    if status:
        query = query.filter(Report.status == status)
    reports = query.order_by(desc(Report.created_at)).limit(min(limit, 200)).all()
    return [_report_to_out(r) for r in reports]


@router.get("/track/{tracking_id}", response_model=ReportOut)
def track_report(tracking_id: str, db: Session = Depends(get_db)):
    report = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files)).filter(Report.tracking_id == tracking_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Tracking ID not found")
    return _report_to_out(report)


@router.get("/{report_id}", response_model=ReportOut)
def get_report(report_id: int, db: Session = Depends(get_db)):
    report = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files)).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    return _report_to_out(report)


@router.patch("/{report_id}/status", response_model=ReportOut)
def update_status(report_id: int, payload: StatusUpdate, db: Session = Depends(get_db)):
    allowed = {
        "SUBMITTED", "AI_CHECKED", "MODERATOR_REVIEWING", "MORE_EVIDENCE_NEEDED",
        "SENT_TO_AGENCY", "AGENCY_DEADLINE_STARTED", "CONFIRMED", "NOT_CONFIRMED",
        "REWARD_REVIEW", "CLOSED"
    }
    if payload.status not in allowed:
        raise HTTPException(status_code=400, detail=f"Invalid status. Allowed: {sorted(allowed)}")

    report = _load_report_or_404(db, report_id)
    report.status = payload.status
    report.updated_at = datetime.utcnow()
    add_timeline(
        db,
        report,
        payload.status,
        payload.status.replace("_", " ").title(),
        payload.message or f"Status changed to {payload.status}.",
    )
    if payload.message:
        db.add(ModeratorMessage(report_id=report.id, sender="Moderator", message=payload.message))
    db.commit()

    loaded = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files)).filter(Report.id == report_id).first()
    return _report_to_out(loaded)


@router.post("/{report_id}/messages", response_model=ReportOut)
def add_message(report_id: int, payload: ModeratorMessageCreate, db: Session = Depends(get_db)):
    report = _load_report_or_404(db, report_id)
    db.add(ModeratorMessage(report_id=report.id, sender=payload.sender, message=payload.message))
    db.commit()
    loaded = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files)).filter(Report.id == report_id).first()
    return _report_to_out(loaded)


@router.post("/{report_id}/evidence", response_model=ReportOut)
async def upload_evidence(report_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)):
    report = _load_report_or_404(db, report_id)
    content = await file.read()
    if len(content) > MAX_FILE_SIZE:
        raise HTTPException(status_code=413, detail="File too large. Max size is 25 MB.")
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(status_code=400, detail=f"Unsupported file type: {file.content_type}")

    ensure_upload_dir(UPLOAD_DIR)
    stored_name = safe_filename(file.filename or "evidence")
    path = os.path.join(UPLOAD_DIR, stored_name)
    with open(path, "wb") as f:
        f.write(content)

    evidence = EvidenceFile(
        report_id=report.id,
        original_name=file.filename or "evidence",
        stored_name=stored_name,
        content_type=file.content_type,
        size_bytes=len(content),
        sha256=sha256_bytes(content),
    )
    db.add(evidence)
    add_timeline(db, report, "EVIDENCE_UPLOADED", "Evidence uploaded", "A file was attached and hashed for integrity.")

    # Re-run AI after evidence arrives to improve evidence strength/reward potential.
    ai_result = analyze_report({
        "category": report.category,
        "description": report.description,
        "location": report.location,
        "region": report.region,
        "organization": report.organization,
        "incident_date": report.incident_date,
        "has_evidence": True,
        "anonymous": report.anonymous,
        "danger_flag": report.danger_flag,
    })
    report.ai_score = int(ai_result.get("risk_score", report.ai_score))
    report.ai_result = json.dumps(ai_result, ensure_ascii=False)
    report.reward_status = ai_result.get("reward_potential", report.reward_status)
    report.updated_at = datetime.utcnow()
    db.commit()

    loaded = db.query(Report).options(selectinload(Report.timeline), selectinload(Report.messages), selectinload(Report.evidence_files)).filter(Report.id == report_id).first()
    return _report_to_out(loaded)
