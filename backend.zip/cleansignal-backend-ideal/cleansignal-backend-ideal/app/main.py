import os
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.database import Base, engine
from app.routers import contact, reports, stats

load_dotenv()

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="CleanSignal Backend",
    description="Stable FastAPI backend for CleanSignal anti-corruption MVP with SQLite, file upload, tracking, stats, and optional OpenAI AI integration.",
    version="1.0.0",
)

origins_env = os.getenv("ALLOWED_ORIGINS", "*")
origins = [o.strip() for o in origins_env.split(",") if o.strip()]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins if origins != ["*"] else ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(reports.router)
app.include_router(stats.router)
app.include_router(contact.router)


@app.get("/health", tags=["system"])
def health():
    return {"status": "ok", "service": "cleansignal-backend"}


@app.get("/", tags=["system"])
def root():
    return {
        "message": "CleanSignal Backend is running",
        "docs": "/docs",
        "health": "/health",
    }