import requests

BASE = "http://127.0.0.1:8000"

payload = {
    "category": "education",
    "description": "A parent was asked for an unofficial cash payment to speed up school admission documents. This happened near the admission office.",
    "location": "Tashkent",
    "region": "Tashkent",
    "organization": "Demo School",
    "incident_date": "2026-04-25",
    "anonymous": True,
    "danger_flag": False,
    "has_evidence": False,
}

r = requests.post(f"{BASE}/reports", json=payload, timeout=10)
r.raise_for_status()
data = r.json()
print("Created:", data["tracking_id"], data["ai_result"])

track = requests.get(f"{BASE}/reports/track/{data['tracking_id']}", timeout=10)
track.raise_for_status()
print("Tracked:", track.json()["status"])

stats = requests.get(f"{BASE}/stats", timeout=10)
stats.raise_for_status()
print("Stats total:", stats.json()["total_reports"])
